const menuItems1 = [
  "Home",
  "About Us",
  "Quarterly",
  "Report/Annual",
  "Site Map",
  "Campus Map",
];

const menuItems2 = [
  "Brochure",
  "E Learning System(moodle)",
  "Student Info",
  "Scholarship",
  "Alumni Association",
  "Co-Cur Activites",
];

const menuItems3 = [
  "AICTE Feedback",
  "L&T EduTech Courses",
  "Sports",
  "Academic Calendar",
  "Careers",
  "Contact us",
];

export { menuItems1, menuItems2, menuItems3 };
