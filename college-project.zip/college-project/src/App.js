import Footer from "./components/Footer";

function App() {
  return (
    <div>
      <Footer />
    </div>
  );
}

export default App;
